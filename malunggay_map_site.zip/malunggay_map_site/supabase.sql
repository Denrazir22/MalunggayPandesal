create table if not exists public.malunggay_sightings (
  id bigint generated always as identity primary key,
  location_name text not null,
  latitude double precision not null,
  longitude double precision not null,
  seen_at timestamptz not null default now()
);

alter table public.malunggay_sightings enable row level security;

create policy "Allow public read"
on public.malunggay_sightings
for select
using (true);

create policy "Allow public insert"
on public.malunggay_sightings
for insert
with check (true);
