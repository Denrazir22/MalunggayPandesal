# Saan may Malunggay Hot Pandesal?

A GitHub Pages-ready crowd mapping website for logging sightings of malunggay hot pandesal stalls.

## What it collects
- Location / landmark
- Latitude
- Longitude
- Date and time seen

## Deploy on GitHub Pages
1. Create a new GitHub repository.
2. Upload `index.html`.
3. Go to **Settings > Pages**.
4. Set the source to your main branch root.
5. Save and wait for the site to publish.

## Make submissions live for everyone
GitHub Pages only hosts static files, so use Supabase as the database.

1. Create a Supabase project.
2. Run the SQL in `supabase.sql`.
3. Open `index.html`.
4. Replace:
   - `YOUR_SUPABASE_URL`
   - `YOUR_SUPABASE_ANON_KEY`
5. Commit and push again.

## Notes
- Without Supabase, the site runs in demo mode.
- The map uses Leaflet and OpenStreetMap.
